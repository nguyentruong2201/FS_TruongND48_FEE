const profile = document.getElementById("profileMenu");
const dropdown = document.getElementById("dropdownMenu");
const dropdownToggle = document.getElementById("dropdownToggle");

function toggleDropdown(e) {
    e.stopPropagation();
    if (dropdown.style.display === "block") {
        dropdown.style.display = "none";
    } else {
        dropdown.style.display = "block";
    }
}

profile.addEventListener("click", toggleDropdown);
dropdownToggle.addEventListener("click", toggleDropdown);

document.addEventListener("click", (e) => {
    if (!profile.contains(e.target) && !dropdownToggle.contains(e.target) && !dropdown.contains(e.target)) {
        dropdown.style.display = "none";
    }
});
