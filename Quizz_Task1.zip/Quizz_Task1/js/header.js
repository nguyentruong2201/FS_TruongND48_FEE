const profile = document.getElementById("profileMenu");
const dropdown = document.getElementById("dropdownMenu");

profile.addEventListener("click", () => {
    dropdown.classList.toggle("active");
});

document.addEventListener("click", (e) => {
    if (!profile.contains(e.target)) {
        dropdown.classList.remove("active");
    }
});
